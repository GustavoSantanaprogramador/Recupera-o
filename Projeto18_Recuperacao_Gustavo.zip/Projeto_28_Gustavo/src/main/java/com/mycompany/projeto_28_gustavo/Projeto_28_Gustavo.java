/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.projeto_28_gustavo;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author gsantana
 */
public class Projeto_28_Gustavo {

    public static void main(String[] args) throws IOException{
        Scanner sc = new Scanner(System.in);
        Scanner ler = new Scanner(System.in);
        int valorUsuario = 0;
        String nomeArquivo = "";
        String nomeLutador = "";
        int pesoLutador = 0;
        
        Date date = new Date();
        String localSalvo  = "";
        
     
        // lOCAL PARA SALVAR O ARQUIVO
        System.out.println("-----------Lutador-----------");
        System.out.println("\nInforme um nome parao arquivo: ");
        nomeArquivo =sc.next();
        sc.nextLine();
        
        System.out.println("\n Informe um lugar para salvar o arquivo:");
        localSalvo =sc.next();
        sc.nextLine();
        FileWriter arquivo = new FileWriter(localSalvo + nomeArquivo + ".txt");
        PrintWriter escrever = new PrintWriter(arquivo);
        
       
        
      // condições
        System.out.printf("Digite o seu nome: ");
        nomeLutador = ler.next();
        ler.nextLine();
        
        System.out.printf("Digite o seu peso: ");
        pesoLutador = ler.nextInt();
        ler.nextLine();
        
        //dados lutador
        if(pesoLutador < 65){
          System.out.println("Seu peso é Pena");
          escrever.printf("Lutador: " + nomeLutador +"\n" +"Seu peso é Pena" );
          
        }else if(pesoLutador > 65 & pesoLutador < 72){
           escrever.printf("Lutador: " + nomeLutador + "\n" +"Seu peso é Leve");
            
        }else if(pesoLutador > 72 & pesoLutador <79){
              escrever.printf("Lutador: " + nomeLutador + "\n"+ "Seu peso é Meio Médio");
            
        }else if(pesoLutador > 79 & pesoLutador < 86){
            System.out.println("Seu peso é Médio");
            escrever.printf("Lutador: " + nomeLutador + "\n"+ "Seu peso é Médio");
            
        }else if(pesoLutador > 86 & pesoLutador <93){
            escrever.printf("Lutador: " + nomeLutador + "\n " + "Seu peso é Meio Pesado" );
            
        }else if (pesoLutador > 93 & pesoLutador <100){
            escrever.printf("Lutador: " + nomeLutador + "Peso" + "Pesado" );
        }
     
    arquivo.close();
        
        
        
        
        
        
        
        
        
        
    }
}
